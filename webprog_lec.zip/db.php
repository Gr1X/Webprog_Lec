<?php
    $dsn = "mysql:host=localhost;dbname=mene";
    $db = new PDO($dsn, "root", "");
?>